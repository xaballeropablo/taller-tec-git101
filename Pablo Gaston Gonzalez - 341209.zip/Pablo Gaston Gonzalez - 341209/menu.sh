#!/bin/bash

menu() {

    echo "Bienvenido al menú principal:"
    echo "1. Lista de usuarios"
    echo "2. Registrar nuevo usuario"
    echo "3. Eliminar usuario"
    echo "4. Salir"

    read -p "Ingrese su elección: " choice

    case $choice in 

        1) list_users ;; 
        2) add_users ;;
        3) delete_users ;;
        4) exit ;;

    esac

}