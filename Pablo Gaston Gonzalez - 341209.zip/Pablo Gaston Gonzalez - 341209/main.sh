#!/bin/bash

source users.sh
source menu.sh

echo "Autenticación requerida"
authenticate_user

while true; do
    menu
done